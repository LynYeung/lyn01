import socket

# 创建tcp套接字
sockfd = socket.socket()  # 使用默认参数
server_addr = ("192.168.1.13", 8888) # 设置服务端地址
sockfd.connect(server_addr)

# 发送消息
while 1:
    data = input("Msg>>")
    sockfd.send(data.encode())
    if data == "q":
        break
    data = sockfd.recv(1024)
    print("sevrver:", data.decode())

# # 关闭套接字
# sockfd.close()